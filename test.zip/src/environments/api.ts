export const api = {
    url: 'https://api.pokemontcg.io/v2/'
};
  